package mh_TelBook.view;

public class end {
	// 종료 코드
		public static void End() {
			System.out.println("::::::::::::::: END :::::::::::::::");
			System.out.println("프로그램 종료!");
			System.out.println("수고하셨습니다.");
			System.exit(0);
		}
}
