package pratice_3;

public class Ex13 {

	public static void main(String[] args) {
		for(int i = 1; i<100; i++) {
			if(i%3==0) {
				System.out.printf("%d 박수 짝\n",i);
			}
		}
	}

}
